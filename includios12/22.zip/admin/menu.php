<?php
$aMenu = array(
    "parent_menu" => "global_menu_mycompany",
    "sort" => 100,
    "text" => "Конструктор баннеров",
    "title" => "Перейти в конструктор",
    "url" => "mycompany_banner_constructor.php?lang=" . LANGUAGE_ID,
    "icon" => "sys_menu_icon",
    "page_icon" => "sys_page_icon",
    "items_id" => "menu_mycompany_banner_constructor",
    "items" => []
);
return $aMenu;