<?php
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\EventManager;

class mycompany_banner extends CModule
{
    public $MODULE_ID = "mycompany.banner";
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $PARTNER_NAME;
    public $PARTNER_URI;

    public function __construct()
    {
        $arModuleVersion = array();
        include(__DIR__ . "/version.php");
        $this->MODULE_VERSION = $arModuleVersion["VERSION"];
        $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
        $this->MODULE_NAME = "Модуль Баннеров";
        $this->MODULE_DESCRIPTION = "Модуль для управления баннерами";
        $this->PARTNER_NAME = "Моя Компания";
        $this->PARTNER_URI = "http://mycompany.ru";
    }

    public function DoInstall()
    {
        ModuleManager::registerModule($this->MODULE_ID);
        $this->InstallFiles();
        $this->InstallDB();
        $this->RegisterEvents();
    }

    public function DoUninstall()
    {
        $this->UnRegisterEvents();
        $this->UnInstallDB();
        $this->UnInstallFiles();
        ModuleManager::unRegisterModule($this->MODULE_ID);
    }
    
    public function InstallFiles()
    {
        // Копируем компоненты
        CopyDirFiles(
            $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/components",
            $_SERVER["DOCUMENT_ROOT"] . "/bitrix/components",
            true, true
        );
        
        // Копируем админскую страницу
        CopyDirFiles(
            $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/admin",
            $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin",
            true, true
        );
        
        // Важно: переименовываем файл при копировании, чтобы он был уникальным в папке /bitrix/admin/
        // Битрикс требует, чтобы файлы модулей в общей папке имели префикс модуля
        if (file_exists($_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/banner_settings.php")) {
            rename(
                $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/banner_settings.php",
                $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/mycompany_banner_settings.php"
            );
        }
        
        return true;
    }

    public function UnInstallFiles()
    {
        DeleteDirFilesEx("/bitrix/components/mycompany/banner");
        // Удаляем админский файл
        DeleteDirFilesEx("/bitrix/admin/mycompany_banner_settings.php");
        return true;
    }

    public function InstallDB() {}
    public function UnInstallDB() {}
    
    public function RegisterEvents() {
        $eventManager = EventManager::getInstance();
        $eventManager->registerEventHandler("main", "OnBuildGlobalMenu", $this->MODULE_ID, "\MyCompany\Banner\Event", "onBuildGlobalMenu");
    }

    public function UnRegisterEvents() {
        $eventManager = EventManager::getInstance();
        $eventManager->unRegisterEventHandler("main", "OnBuildGlobalMenu", $this->MODULE_ID, "\MyCompany\Banner\Event", "onBuildGlobalMenu");
    }
}