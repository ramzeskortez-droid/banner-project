<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
/** @var CBitrixComponentTemplate $this */
/** @var array $arParams */
/** @var array $arResult */

// 1. Формируем классы для карточки
$cardClasses = 'my-banner-card';
if (isset($arResult['IMAGE_POSITION']) && $arResult['IMAGE_POSITION'] === 'right') {
    $cardClasses .= ' reverse'; // Добавляем класс для реверса
}
?>
<div class="my-banner-wrapper">
    <a href="<?=htmlspecialcharsbx($arResult["LINK_URL"])?>" class="<?=$cardClasses?>" style="background-color: <?=htmlspecialcharsbx($arResult["THEME_COLOR"])?>;">
        <div class="my-banner-content">
            <div class="my-banner-title"><?=$arResult["TITLE"]?></div>
            <div class="my-banner-text"><?=$arResult["ANNOUNCEMENT"] // Используем ANNOUNCEMENT ?></div>
            <div class="my-banner-btn">Подробнее →</div>
        </div>
        <?php if(!empty($arResult["IMAGE_LINK"])): ?>
            <div class="my-banner-image"><img src="<?=htmlspecialcharsbx($arResult["IMAGE_LINK"])?>" alt="Баннер"></div>
        <?php else: ?>
            <div class="my-banner-image-placeholder"><span>IMG</span></div>
        <?php endif; ?>
        <div class="glitch-lines"></div>
    </a>
</div>