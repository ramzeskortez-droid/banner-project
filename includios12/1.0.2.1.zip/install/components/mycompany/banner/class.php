<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;

class MyCompanyBanner extends \CBitrixComponent
{
    /**
     * Подготовка параметров компонента
     * @param array $arParams
     * @return array
     */
    public function onPrepareComponentParams($arParams)
    {
        $moduleId = 'mycompany.banner';

        // 1. Механизм наследования настроек из модуля
        if (empty($arParams['THEME_COLOR'])) {
            $arParams['THEME_COLOR'] = Option::get($moduleId, 'THEME_COLOR', '#f5f5f5');
        }
        if (empty($arParams['TITLE'])) {
            $arParams['TITLE'] = Option::get($moduleId, 'DEFAULT_TITLE', 'Заголовок по умолчанию');
        }
        if (empty($arParams['ANNOUNCEMENT'])) {
            $arParams['ANNOUNCEMENT'] = Option::get($moduleId, 'DEFAULT_ANNOUNCEMENT', 'Анонс по умолчанию.');
        }

        // Если ссылка не установлена в режиме без категорий, берем дефолтную
        if ($arParams['CATEGORY_MODE'] !== 'Y' && empty($arParams['LINK_URL'])) {
             $arParams['LINK_URL'] = Option::get($moduleId, 'DEFAULT_LINK', '/');
        }
        
        $arParams['CATEGORY_MODE'] = isset($arParams['CATEGORY_MODE']) ? strtoupper($arParams['CATEGORY_MODE']) : 'N';
        $arParams['CATEGORY_ID'] = isset($arParams['CATEGORY_ID']) ? intval($arParams['CATEGORY_ID']) : 0;

        return $arParams;
    }

    /**
     * Выполнение компонента
     */
    public function executeComponent()
    {
        $this->arResult['LINK_URL'] = '';

        // 2. Логика получения ссылки
        if ($this->arParams['CATEGORY_MODE'] === 'Y' && $this->arParams['CATEGORY_ID'] > 0) {
            // Если включен режим категорий, получаем ссылку на раздел
            if (Loader::includeModule('iblock')) {
                $res = \CIBlockSection::GetByID($this->arParams['CATEGORY_ID']);
                if($section = $res->GetNext()) {
                    $this->arResult['LINK_URL'] = $section['SECTION_PAGE_URL'];
                }
            }
        } else {
            // Иначе используем прямую ссылку
            $this->arResult['LINK_URL'] = $this->arParams['LINK_URL'];
        }
        
        // 3. Передаем остальные параметры в результат для удобства
        $this->arResult['TITLE'] = htmlspecialchars_decode($this->arParams['TITLE']);
        $this->arResult['ANNOUNCEMENT'] = htmlspecialchars_decode($this->arParams['ANNOUNCEMENT']);
        $this->arResult['IMAGE_LINK'] = $this->arParams['IMAGE_LINK'];
        $this->arResult['IMAGE_POSITION'] = $this->arParams['IMAGE_POSITION'];
        $this->arResult['THEME_COLOR'] = $this->arParams['THEME_COLOR'];

        $this->includeComponentTemplate();
    }
}