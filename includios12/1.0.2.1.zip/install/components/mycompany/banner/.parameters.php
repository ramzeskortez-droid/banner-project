<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;

// 1. Подключаем модуль инфоблоков
$iblockIncluded = Loader::includeModule('iblock');

$iblockTypes = [];
$iblocks = [];
if ($iblockIncluded) {
    // Получаем типы инфоблоков
    $iblockTypeIterator = CIBlockType::GetList(['SORT' => 'ASC'], []);
    while ($type = $iblockTypeIterator->Fetch()) {
        if ($typeLang = CIBlockType::GetByIDLang($type['ID'], LANGUAGE_ID)) {
            $iblockTypes[$type['ID']] = '[' . $type['ID'] . '] ' . $typeLang['NAME'];
        }
    }

    // Получаем инфоблоки
    $iblockIterator = CIBlock::GetList(
        ['SORT' => 'ASC'],
        ['ACTIVE' => 'Y', 'TYPE' => $arCurrentValues['IBLOCK_TYPE']]
    );
    while ($iblock = $iblockIterator->Fetch()) {
        $iblocks[$iblock['ID']] = '[' . $iblock['ID'] . '] ' . $iblock['NAME'];
    }
}

// 2. Логика для выбора разделов
$categories = [];
if ($iblockIncluded && !empty($arCurrentValues['IBLOCK_ID']) && $arCurrentValues['CATEGORY_MODE'] == 'Y') {
    $sectionIterator = CIBlockSection::GetList(
        ['left_margin' => 'asc'],
        [
            'IBLOCK_ID' => $arCurrentValues['IBLOCK_ID'],
            'ACTIVE' => 'Y',
            'GLOBAL_ACTIVE' => 'Y',
        ],
        false,
        ['ID', 'NAME', 'DEPTH_LEVEL']
    );
    while ($section = $sectionIterator->Fetch()) {
        $categories[$section['ID']] = str_repeat(' . ', $section['DEPTH_LEVEL'] - 1) . $section['NAME'];
    }
}

$arComponentParameters = [
    "GROUPS" => [
        "BANNER_SETTINGS" => ["NAME" => "Основные настройки"],
        "DATA_SOURCE" => ["NAME" => "Источник данных"],
    ],
    "PARAMETERS" => [
        "TITLE" => [
            "PARENT" => "BANNER_SETTINGS",
            "NAME" => "Заголовок",
            "TYPE" => "STRING",
            "DEFAULT" => "Акция!",
        ],
        "ANNOUNCEMENT" => [ // Переименовано из SUBTITLE
            "PARENT" => "BANNER_SETTINGS",
            "NAME" => "Анонс", // Новое название
            "TYPE" => "STRING",
            "DEFAULT" => "Описание акции",
        ],
        "IMAGE_LINK" => [
            "PARENT" => "BANNER_SETTINGS",
            "NAME" => "Ссылка на картинку",
            "TYPE" => "STRING",
            "DEFAULT" => "",
        ],
        "IMAGE_POSITION" => [ // Новый параметр
            "PARENT" => "BANNER_SETTINGS",
            "NAME" => "Расположение картинки",
            "TYPE" => "LIST",
            "VALUES" => [
                "left" => "Слева",
                "right" => "Справа",
            ],
            "DEFAULT" => "left",
        ],
        "THEME_COLOR" => [
            "PARENT" => "BANNER_SETTINGS",
            "NAME" => "Цвет фона",
            "TYPE" => "COLORPICKER",
            "DEFAULT" => "#f5f5f5",
        ],
        
        "CATEGORY_MODE" => [ // Новый параметр
            "PARENT" => "DATA_SOURCE",
            "NAME" => "Режим выбора категории",
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
            "REFRESH" => "Y", // Перезагрузка при изменении
        ],
    ],
];

// 3. Динамическое добавление параметров
if ($arCurrentValues['CATEGORY_MODE'] == 'Y') {
    $arComponentParameters['PARAMETERS']['IBLOCK_TYPE'] = [
        "PARENT" => "DATA_SOURCE",
        "NAME" => "Тип инфоблока",
        "TYPE" => "LIST",
        "VALUES" => $iblockTypes,
        "DEFAULT" => "",
        "REFRESH" => "Y",
    ];
    $arComponentParameters['PARAMETERS']['IBLOCK_ID'] = [
        "PARENT" => "DATA_SOURCE",
        "NAME" => "ID Инфоблока",
        "TYPE" => "LIST",
        "VALUES" => $iblocks,
        "DEFAULT" => "",
        "REFRESH" => "Y",
    ];
    if (!empty($categories)) {
        $arComponentParameters['PARAMETERS']['CATEGORY_ID'] = [
            "PARENT" => "DATA_SOURCE",
            "NAME" => "Раздел для ссылки",
            "TYPE" => "LIST",
            "VALUES" => $categories,
            "ADDITIONAL_VALUES" => "Y",
        ];
    }
} else {
    $arComponentParameters['PARAMETERS']['LINK_URL'] = [
        "PARENT" => "DATA_SOURCE",
        "NAME" => "Ссылка при клике (URL)",
        "TYPE" => "STRING",
        "DEFAULT" => "/",
    ];
}