<?php
$aMenu = array(
    "parent_menu" => "global_menu_mycompany",
    "sort" => 100,
    "text" => "Настройки баннеров",
    "title" => "Перейти к настройкам",
    "url" => "mycompany_banner_settings.php?lang=" . LANGUAGE_ID,
    "icon" => "sys_menu_icon",
    "page_icon" => "sys_page_icon",
    "items_id" => "menu_mycompany_banner",
    "items" => array(
        array(
            "text" => "Инструкция",
            "url" => "mycompany_banner_settings.php?lang=" . LANGUAGE_ID,
        ),
    )
);
return $aMenu;