<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

use Bitrix\Main\Config\Option;
use Bitrix\Main\HttpApplication;
use Bitrix\Main\Loader;

$module_id = "mycompany.banner";
Loader::includeModule($module_id);
$APPLICATION->SetTitle("Настройки баннеров");

$request = HttpApplication::getInstance()->getContext()->getRequest();

// 1. Обработка сохранения
if ($request->isPost() && $request["apply"] && check_bitrix_sessid()) {
    // Сохранение цвета
    if($request["THEME_COLOR"]) {
        Option::set($module_id, "THEME_COLOR", $request["THEME_COLOR"]);
    }
    if($request["CUSTOM_COLOR_VAL"]) {
        Option::set($module_id, "CUSTOM_COLOR_VAL", $request["CUSTOM_COLOR_VAL"]);
    }
    
    // Сохранение нового контента по умолчанию
    Option::set($module_id, "DEFAULT_TITLE", $request["DEFAULT_TITLE"]);
    Option::set($module_id, "DEFAULT_ANNOUNCEMENT", $request["DEFAULT_ANNOUNCEMENT"]);
    Option::set($module_id, "DEFAULT_LINK", $request["DEFAULT_LINK"]);

    LocalRedirect($APPLICATION->GetCurPage()."?lang=".LANGUAGE_ID."&success=Y");
}

// 2. Получение текущих значений
$currentColor = Option::get($module_id, "THEME_COLOR", "#ff0000");
$customColorVal = Option::get($module_id, "CUSTOM_COLOR_VAL", "");
$defaultTitle = Option::get($module_id, "DEFAULT_TITLE", "");
$defaultAnnouncement = Option::get($module_id, "DEFAULT_ANNOUNCEMENT", "");
$defaultLink = Option::get($module_id, "DEFAULT_LINK", "/");

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
?>

<!-- 3. Стили интерфейса -->
<style>
    .settings-container { font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; background: #f5f9f9; padding: 20px; border-radius: 4px; }
    .settings-card { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 20px; max-width: 900px; }
    .card-title { font-size: 20px; font-weight: 600; margin-bottom: 25px; border-bottom: 1px solid #eee; padding-bottom: 15px; color: #333; }
    
    .form-group { margin-bottom: 30px; }
    .form-label { display: block; font-weight: 600; margin-bottom: 15px; color: #555; font-size: 14px; }
    .text-input { width: 100%; padding: 10px 15px; border-radius: 4px; border: 1px solid #ddd; box-sizing: border-box; }
    
    /* Цветовые переключатели */
    .color-presets { display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
    .color-option { width: 45px; height: 45px; border-radius: 50%; cursor: pointer; border: 2px solid transparent; transition: all 0.2s; position: relative; }
    .color-option:hover { transform: scale(1.1); }
    .color-option.active { border-color: #333; transform: scale(1.15); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .color-option.active::after { content: '✓'; color: #fff; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 20px; text-shadow: 0 1px 2px rgba(0,0,0,0.3); }

    .custom-color-input { margin-left: 15px; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 100px; }
    
    .save-panel { padding-top: 20px; }
    .btn-submit { background: #2bc647; color: #fff; border: none; padding: 12px 30px; font-size: 15px; font-weight: bold; border-radius: 30px; cursor: pointer; transition: background 0.2s; }
    .btn-submit:hover { background: #35d852; }
</style>

<div class="settings-container">
    <?php if($request["success"] == "Y"): ?>
        <div style="padding: 15px; background: #d4edda; color: #155724; border-radius: 4px; margin-bottom: 20px;">
            Настройки успешно сохранены!
        </div>
    <?php endif; ?>

    <form method="post" action="<?echo $APPLICATION->GetCurPage()?>?lang=<?=LANGUAGE_ID?>" id="settingsForm">
        <?=bitrix_sessid_post()?>
        
        <!-- Блок с настройками по умолчанию -->
        <div class="settings-card">
            <div class="card-title">Содержимое по умолчанию</div>
            <div class="form-group">
                <label class="form-label">Дефолтный Заголовок</label>
                <input type="text" name="DEFAULT_TITLE" value="<?=htmlspecialcharsbx($defaultTitle)?>" class="text-input">
            </div>
            <div class="form-group">
                <label class="form-label">Дефолтный Анонс</label>
                <input type="text" name="DEFAULT_ANNOUNCEMENT" value="<?=htmlspecialcharsbx($defaultAnnouncement)?>" class="text-input">
            </div>
            <div class="form-group">
                <label class="form-label">Дефолтная ссылка</label>
                <input type="text" name="DEFAULT_LINK" value="<?=htmlspecialcharsbx($defaultLink)?>" class="text-input">
            </div>
        </div>
        
        <!-- Блок с цветами -->
        <div class="settings-card">
            <div class="card-title">Цветовая схема сайта</div>
            <div class="form-group">
                <label class="form-label">Базовый цвет оформления</label>
                <div class="color-presets">
                    <?php 
                    $colors = ['#ff4d4d', '#ff9f43', '#feca57', '#1dd1a1', '#5f27cd', '#54a0ff', '#2e86de'];
                    foreach($colors as $c): ?>
                        <div class="color-option <?=$currentColor == $c ? 'active' : ''?>" 
                             style="background: <?=$c?>" 
                             onclick="selectColor(this, '<?=$c?>')"></div>
                    <?php endforeach; ?>
                    
                    <div style="display: flex; align-items: center; margin-left: 20px; border-left: 1px solid #eee; padding-left: 20px;">
                        <span style="font-size: 13px; color: #777; margin-right: 10px;">Свой цвет:</span>
                        <input type="color" id="customColorPicker" value="<?=$customColorVal?>" onchange="selectCustomColor(this.value)">
                    </div>
                </div>
                
                <input type="hidden" name="THEME_COLOR" id="themeColorInput" value="<?=$currentColor?>">
                <input type="hidden" name="CUSTOM_COLOR_VAL" id="customColorValInput" value="<?=$customColorVal?>">
            </div>
        </div>

        <div class="save-panel">
            <input type="submit" name="apply" value="Применить настройки" class="btn-submit">
        </div>
    </form>
</div>

<script>
    function selectColor(element, color) {
        document.getElementById('themeColorInput').value = color;
        document.querySelectorAll('.color-option').forEach(el => el.classList.remove('active'));
        element.classList.add('active');
        document.getElementById('customColorValInput').value = '';
    }

    function selectCustomColor(color) {
        document.getElementById('themeColorInput').value = color;
        document.getElementById('customColorValInput').value = color;
        document.querySelectorAll('.color-option').forEach(el => el.classList.remove('active'));
    }
</script>

<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
