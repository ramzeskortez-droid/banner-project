<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;
use MyCompany\Banner\BannerTable;

$banners = [];
if (Loader::includeModule('mycompany.banner')) {
    $result = BannerTable::getList([
        'select' => ['ID', 'NAME'],
        'order' => ['ID' => 'ASC']
    ]);
    while ($row = $result->fetch()) {
        $banners[$row['ID']] = "[{$row['ID']}] " . $row['NAME'];
    }
}

$arComponentParameters = [
    "GROUPS" => [
        "BASE" => ["NAME" => "Основной параметр"],
    ],
    "PARAMETERS" => [
        "BANNER_ID" => [
            "PARENT" => "BASE",
            "NAME" => "Выберите баннер",
            "TYPE" => "LIST",
            "VALUES" => $banners,
            "ADDITIONAL_VALUES" => "N",
            "REFRESH" => "N",
        ],
    ],
];