<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;
use MyCompany\Banner\BannerTable;

class MyCompanyBanner extends \CBitrixComponent
{
    public function executeComponent()
    {
        $bannerId = (int)$this->arParams['BANNER_ID'];
        if ($bannerId <= 0) {
            return;
        }

        if (Loader::includeModule('mycompany.banner')) {
            $banner = BannerTable::getById($bannerId)->fetch();

            if ($banner) {
                // Передаем все данные баннера в результат
                $this->arResult = [
                    'TITLE' => $banner['TITLE'],
                    'ANNOUNCEMENT' => $banner['ANNOUNCEMENT'],
                    'IMAGE_LINK' => $banner['IMAGE_LINK'],
                    'IMAGE_POSITION' => $banner['IMAGE_POSITION'],
                    'LINK_URL' => $banner['LINK_URL'],
                    'THEME_COLOR' => $banner['THEME_COLOR'],
                ];
            }
        }

        $this->includeComponentTemplate();
    }
}